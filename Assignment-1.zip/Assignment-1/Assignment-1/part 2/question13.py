for num in range(1500, 2001):
    if num % 7 == 0 and num % 5 == 0:
        print(num)
