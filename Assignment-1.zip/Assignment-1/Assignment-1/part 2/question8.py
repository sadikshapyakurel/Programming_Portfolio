char = input("Enter a single character: ").lower()

if len(char) == 1 and char.isalpha():
    if char in 'aeiou':
        print(char, "is a vowel.")
    else:
        print(char, "is a consonant.")
else:
    print("Please enter a single alphabet character.")
