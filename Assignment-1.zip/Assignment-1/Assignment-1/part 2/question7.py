temp = float(input("Enter temperature in Celsius: "))

if temp < 10:
    print("It's Cold.")
elif temp <= 25:
    print("It's Warm.")
else:
    print("It's Hot.")
