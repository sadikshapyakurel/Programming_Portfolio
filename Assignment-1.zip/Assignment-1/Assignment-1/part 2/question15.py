import random

answer = random.randint(1, 100)  # 1 देखि 100 सम्मको random number generate गर्छ
attempts = 5

print("Guess the number between 1 and 100. You have 5 attempts.")

for i in range(attempts):
    guess = int(input(f"Attempt {i+1}: Enter your guess: "))
    
    if guess == answer:
        print("Correct number! You won!")
        break
    elif guess < answer:
        print("Too low")
    else:
        print("Too high")
else:
    print("Game Over! The correct number was", answer)
