# 1 kilometer = 0.621371 miles

km = float(input("Enter distance in kilometers: "))
miles = km * 0.621371

print(f"{km} kilometers is equal to {miles:.3f} miles.")
