num1 = int(input("Enter the first integer: "))
num2 = int(input("Enter the second integer: "))
quotient = num1 // num2
remainder = num1 % num2
print("Quotient:", quotient)
print("Remainder:", remainder)
