import math
sqrt_value = math.sqrt(625)
print(sqrt_value)
