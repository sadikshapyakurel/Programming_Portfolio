base = 8
height = 12
area = 0.5 * base * height
# Display the area
print("The area of the triangle is:", area)
