surname = "Pyakurel"
result = (surname + "-") * 2 + surname
print(result)
