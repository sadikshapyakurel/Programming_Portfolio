quotient = 200 // 12
remainder = 200 % 12
print("Quotient:", quotient)
print("Remainder:", remainder)
