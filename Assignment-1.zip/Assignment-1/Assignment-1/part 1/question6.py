name = "Sadiksha"
right_justified_name = name.rjust(20)
print(f"'{right_justified_name}'")
