number = 4729
sum_of_digits = sum(int(digit) for digit in str(number))
print(sum_of_digits)
