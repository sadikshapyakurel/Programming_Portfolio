result = 5**3 + 4**2
print(result)
