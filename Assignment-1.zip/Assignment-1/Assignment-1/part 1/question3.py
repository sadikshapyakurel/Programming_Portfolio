abs_difference = abs(7**3 - 3**7)
print(abs_difference)
