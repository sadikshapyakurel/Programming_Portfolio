number = 9.9999
integer_part = int(number)
rounded_value = round(number, 2)
print("Integer part:", integer_part)
print("Rounded to 2 decimals:", rounded_value)
