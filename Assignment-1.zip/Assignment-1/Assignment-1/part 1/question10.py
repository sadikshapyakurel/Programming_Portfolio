codes = [80, 121, 116, 104, 111, 110]
characters = ''.join(chr(code) for code in codes)
print(characters)
